<!DOCTYPE html>
<html lang="en">
<body>
    <span><b>Hi</b></span> <span style="color:gray">{{$name}},</span>
    <p>
        Please send your some payment within 15 date in this month.
        <br/>
        <br/>
        <b style="color:green">Best Regards,</b><br/>
        {{env('APP_NAME')}} Support Team
    </p>
</body>
</html>