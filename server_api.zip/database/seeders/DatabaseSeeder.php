<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Database\Seeders\DailyMealItemSeeder;
use Hash;
class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // User::create([
        //     'name' => "Md Anwar Hossain",
        //     'username' => "anwar7736",
        //     'email' => "anwarhossain7736@gmail.com",
        //     'phone' => "01794030592",
        //     'password' => Hash::make('123'),
        //     'created_at' => now(),
        //     'updated_at' => now(),
        // ]);

        $this->call([
            DailyMealItemSeeder::class,
        ]);
    }
}
